/** Global Scope */
const LIMIT_POSTS     = WPURLS.limit_posts;
const ALL_MESSAGES    = WPURLS.rest_url + 'contactor/inbox';
const UNREAD_MESSAGES = WPURLS.rest_url + 'contactor/inbox/unread';
const TRASH_MESSAGES  = WPURLS.rest_url + 'contactor/inbox/trash';

var CURRENT_STATE = '';

class ContactorContent {
   
    create( item ){
        
        var trashDisabled = '';
        var readDisabled = '';

        if( item.contactor_status == 'trash' ){
            
            var trashDisabled = 'disabled';
            var readDisabled = 'disabled';

        }

        if( item.contactor_status == 'seen' ){
            
            var readDisabled = 'disabled';

        }

        return `
        <tr id='row-${item.contactor_id}'>
            <td>${item.contactor_id}</td>
            <td>${item.contactor_name}</td>
            <td>${item.contactor_email}</td>
            <td class='message-box'>${item.contactor_message}</td>
            <td>
                <button data-id='${item.contactor_id}' class='send-to-trash' ${trashDisabled}>Delete</button>
                <button data-id='${item.contactor_id}' class='mark-as-read' ${readDisabled}>Mark as read</button>
                <button data-id='${item.contactor_id}' class='remove'>Remove</button>
            </td>
        </tr> `;
    } 

}

class ContactorLoop{
    
    constructor( wrapperId ){
        this.listWrapper = jQuery(wrapperId);

        this.contactorCreator = new ContactorContent();
    }

    create( itemsArray ) {

        this.listWrapper.html("");

        if( itemsArray.length < 1 ){
            this.listWrapper.append("<tr><td colspan='5'>Currently there is no content!</td></tr>");
        } else {
            itemsArray.map((singleItem) => {
                this.listWrapper.append(this.contactorCreator.create(singleItem));
            });
        }
    }

}

class ContactorPaginationBuilder {

    constructor(wrapperId, pages = 0 ) { 
        this.paginationWrapper = jQuery(wrapperId);
        this.paginationPages = pages;
    }

    calculateNumberOfPages(){
        return Math.ceil( this.paginationPages / LIMIT_POSTS );
    }

    create() {
        this.paginationWrapper.html("");
        for( let i = 1; i <= this.calculateNumberOfPages(); i++ ){
            this.paginationWrapper.append(`<li><a href='#' class='pagination-change-page' data-id='${i}'>${i}</a></li>`);
        }
    }

}

class ContactorBuilder {
    
    constructor(){
        this.currentPage = 1;
    }

    changePage( newPage ){
        this.currentPage = newPage;
    }

    calculateOffset(){
        if(this.currentPage < 1){
            return 0;
        }
        return ( ( this.currentPage * LIMIT_POSTS ) - LIMIT_POSTS );
    }

    setCurrentState(newStateConstant){
        CURRENT_STATE = newStateConstant;
    }

    loadContent( requestedResource = ALL_MESSAGES){

        this.setCurrentState(requestedResource);

        jQuery.get(`${requestedResource}/${this.calculateOffset()}`, (response) => {

            console.log(response);

            const contactorLoop       = new ContactorLoop("#contactor-wrapper tbody");
            const contactorPagination = new ContactorPaginationBuilder("#pagination-wrapper", response.count);
                 
            contactorLoop.create(response.response)
            contactorPagination.create();    
                
        });
    }

}

jQuery( () => {

    /** 
     * On page load display initial all messages from inbox 
     * This can be changed if you pass UNREAD_MESSAGES constant
     * instead ALL_MESSAGES
     */
    
    const contactorBuilder = new ContactorBuilder();  
    contactorBuilder.loadContent(UNREAD_MESSAGES);

}); 

jQuery(document).on('click', '.pagination-change-page', function(event){
    
    event.preventDefault();

    const pageId = jQuery(this).attr('data-id');
    const contactorBuilder = new ContactorBuilder();  

    contactorBuilder.changePage(pageId);
    contactorBuilder.loadContent(CURRENT_STATE);

});

jQuery(document).on('click', '.contactor-change-params', function(event){

    event.preventDefault();

    console.log("Promjena parametara");

    const param = jQuery(this).attr('data-constant');
    const contactorBuilder = new ContactorBuilder();  
    var resource = false;

    // Always start from first page
    contactorBuilder.changePage(0);

    switch( param ) {

        case 'ALL'    : { 

            resource = ALL_MESSAGES;

            jQuery('.mark-as-read').hide();
            jQuery('.send-to-trash').show();
            
        } break;
        case 'UNREAD' : { 
            
            resource = UNREAD_MESSAGES; 

            jQuery('.mark-as-read').hide();
            jQuery('.send-to-trash').show();
        
        } break;
        case 'TRASH'  : { 
            
            resource = TRASH_MESSAGES; 

            jQuery('.mark-as-read').css('display', 'none!important');
            jQuery('.send-to-trash').hide();
        
        } break;
    }
    
    contactorBuilder.loadContent(resource);
});

jQuery(document).on('click', '.send-to-trash', function(event){

    event.preventDefault();

    const postId = jQuery(this).attr("data-id");

    if( window.confirm("Are you sure?") ){

        jQuery.ajax({
            type:   "DELETE",
            url: WPURLS.rest_url + "contactor/inbox/delete/" + postId,
            success : function(){
                jQuery(`#row-${postId}`).remove();
            }
        })

    }


});

jQuery(document).on('click', '.remove', function(event){

    event.preventDefault();

    const postId = jQuery(this).attr("data-id");

    if( window.confirm("Are you sure? This will remove your message from system") ){

        jQuery.ajax({
            type:   "DELETE",
            url: WPURLS.rest_url + "contactor/inbox/remove/" + postId,
            success : function(){
                jQuery(`#row-${postId}`).remove();
            }
        })

    }


});

jQuery(document).on('click', '.mark-as-read', function(event){

    event.preventDefault();

    const postId = jQuery(this).attr("data-id");

    if( window.confirm("Are you sure?") ){

        jQuery.ajax({
            type:   "PATCH",
            url: WPURLS.rest_url + "contactor/inbox/read/" + postId,
            success : function(){

                jQuery(`#row-${postId}`).remove();
                jQuery(this).attr('disabled', true);

            }
        })

    }


});