<?php

/*
    Plugin Name:        Contactor
    Plugin Version:     1.0
    Plugin Author:      denis_r_home@yahoo.com
    Description:        Connect Form with Database
*/

require_once("_inc/ContactorTable.php");
require_once("_inc/ContactorMessage.php");
require_once("_inc/Contactor.php");

$contactorTable = new \Contactor\ContactorTable();
$contactorMessages = new \Contactor\ContactorMessage();
$contactor = new \Contactor\Contactor();

// Define some usefull consts
define('ASSETS_DIR', plugin_dir_url(__FILE__) . 'assets/');
define('LIMIT_POSTS_PER_PAGE', 5);

// If table not exists install
// new instance
if( !$contactorTable->checkDidTableExists() ){
    $contactorTable->createTable();
}

// Add all options we need to
// our menu in WP Admin
$contactor->enableAdminOptions();


add_action('admin_init', function(){

        wp_register_style("contactor-main-style", ASSETS_DIR . "css/contactor.css");
        wp_enqueue_style("contactor-main-style");

        wp_register_script("contactor-main-script", ASSETS_DIR . "js/contactor.js");
        wp_enqueue_script("contactor-main-script");

});

