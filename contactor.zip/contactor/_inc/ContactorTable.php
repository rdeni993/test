<?php

/**
 * 
 * Contactor Table is class that
 * handle creating a database table when user 
 * install plugin.
 * 
 */

namespace Contactor;

class ContactorTable {

    public function createTable() : void {

        global $wpdb;

        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `wp_contactor` (
                `contactor_id` int NOT NULL AUTO_INCREMENT,
                `contactor_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'unknown',
                `contactor_email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
                `contactor_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
                `contactor_doc` datetime DEFAULT NULL,
                `contactor_status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
                PRIMARY KEY (`contactor_id`)
              ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3"
        );

    }

    public function checkDidTableExists() : bool {

        global $wpdb;

        if( $wpdb->get_results( "SHOW TABLES LIKE 'wp_contactor'" ) ){
            return true;
        } else {
            return false;
        }
    }

}