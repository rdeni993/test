<?php 

/**
 * 
 * Contactor Message handle request from outside
 * and save it or delete it from database.
 * 
 */

namespace Contactor;

class ContactorMessage {

    /**
     * 
     * At init of the class hook the url
     * to rest api
     * 
     */

    public function __construct() { 

        add_action('rest_api_init', function(){

            register_rest_route(
                'contactor',
                '/income',
                [
                    'methods'   =>  'POST',
                    'callback'  =>  [$this, 'incomeCallback']
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/(?P<offset>\d+)',
                [
                    'methods'   =>  'GET',
                    'callback'  =>  [$this, 'inboxCallback'],
                    'args'      =>  ['offset'] 
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/unread/(?P<offset>\d+)',
                [
                    'methods'   =>  'GET',
                    'callback'  =>  [$this, 'inboxUnreadCallback'],
                    'args'      =>  ['offset'] 
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/trash/(?P<offset>\d+)',
                [
                    'methods'   =>  'GET',
                    'callback'  =>  [$this, 'inboxTrashCallback'],
                    'args'      =>  ['offset'] 
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/read/(?P<id>\d+)',
                [
                    'methods'   =>  'PATCH',
                    'callback'  =>  [$this, 'readMessage'],
                    'args'      =>  ['id']
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/delete/(?P<id>\d+)',
                [
                    'methods'   =>  'DELETE',
                    'callback'  =>  [$this, 'deleteMessage'],
                    'args'      =>  ['id']
                ]
            );

            register_rest_route(
                'contactor',
                '/inbox/remove/(?P<id>\d+)',
                [
                    'methods'   =>  'DELETE',
                    'callback'  =>  [$this, 'removeMessage'],
                    'args'      =>  ['id']
                ]
            );

        });

    }

    public function inboxCallback($data) : array {

        global $wpdb;

        $countRecords = $wpdb->get_var("SELECT count(contactor_id) FROM wp_contactor WHERE contactor_status != 'trash'");

        $offset = $data['offset'];
        $limit  = LIMIT_POSTS_PER_PAGE;

        return [
            'response'  =>  $wpdb->get_results("
                SELECT * FROM wp_contactor WHERE contactor_status != 'trash' ORDER BY contactor_id DESC LIMIT $offset, $limit
            "),

            'limit'     => $data['offset'],
            'count'     => (int)$countRecords
        ];
    }


    public function inboxUnreadCallback($data) : array {

        global $wpdb;

        $countRecords = $wpdb->get_var("SELECT count(contactor_id) FROM wp_contactor WHERE contactor_status = 'unread' AND contactor_status != 'trash'");

        $offset = $data['offset'];
        $limit  = LIMIT_POSTS_PER_PAGE;

        return [
            'response'  =>  $wpdb->get_results("
                SELECT * FROM wp_contactor WHERE contactor_status = 'unread' AND contactor_status != 'trash' ORDER BY contactor_id DESC LIMIT $offset, $limit
            "),

            'limit'     => $data['offset'],
            'count'     => (int)$countRecords
        ];
    }

    public function inboxTrashCallback($data) : array {

        global $wpdb;

        $countRecords = $wpdb->get_var("SELECT count(contactor_id) FROM wp_contactor WHERE contactor_status = 'trash'");

        $offset = $data['offset'];
        $limit  = LIMIT_POSTS_PER_PAGE;

        return [
            'response'  =>  $wpdb->get_results("
                SELECT * FROM wp_contactor WHERE contactor_status = 'trash' ORDER BY contactor_id DESC LIMIT $offset, $limit
            "),

            'limit'     => $data['offset'],
            'count'     => (int)$countRecords
        ];
    }

    public function readMessage($data) : array {

        global $wpdb;

        return [
            'response'  =>  $wpdb->get_results("
                UPDATE wp_contactor SET contactor_status = 'seen' WHERE contactor_id = {$data['id']}
            ")
        ];
    }

    public function deleteMessage($data) : array {

        global $wpdb;

        return [
            'response'  =>  $wpdb->get_results("
                UPDATE wp_contactor SET contactor_status = 'trash' WHERE contactor_id = {$data['id']}
            ")
        ];
    }

    public function removeMessage($data) : array {

        global $wpdb;

        return [
            'response'  =>  $wpdb->get_results("
                DELETE FROM wp_contactor WHERE contactor_id = {$data['id']}
            ")
        ];
    }

    public function incomeCallback() : array {

        global $wpdb;

        $contact_name       =   htmlentities($_POST['name'], ENT_QUOTES);
        $contact_email      =   htmlentities($_POST['email'], ENT_QUOTES);
        $contact_message    =   htmlentities($_POST['message'], ENT_QUOTES);
        $contact_date       =   date('Y-m-d', time());

        return [
            'response'  =>  $wpdb->insert('wp_contactor', [
                'contactor_name'    =>  $contact_name,
                'contactor_email'   =>  $contact_email,
                'contactor_message' =>  $contact_message,
                'contactor_doc'     =>  $contact_date,
                'contactor_status'  =>  'unread'
            ])
        ];
    }

}