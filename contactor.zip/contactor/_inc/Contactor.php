<?php 

namespace Contactor;

class Contactor {

    public function enableAdminOptions() : void {

        add_action('admin_menu', function(){

            //  Enable Button In Wp Menu
            add_menu_page(
                'Contactor Plugin',
                'Contactor Plugin',
                'manage_options',
                'contactor-plugin',
                [$this, 'initContactor']
            );

        });

    }

    /**
     * 
     * First page user open
     * when click on contactor
     * 
     */
    public function initContactor() : void {

        /** Load View File */
        $contactorHomeFile = dirname( __FILE__ ) . "/../views/inbox.php";
        
        try {
            if( file_exists( $contactorHomeFile ) ) {
                include $contactorHomeFile;
            } else {
                throw new \Exception("Inbox File is not found");
            }
        } catch( \Exception $e ){
            echo $e->getMessage();
        }   
    }

}