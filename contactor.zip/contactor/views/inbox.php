<h1>Contactor Inbox</h1>
<h4>Plugin for easy integration contact forms</h4>
<ul class="contactor-menu">
    <li><a href="#" data-constant='UNREAD'  class='contactor-change-params'>Unread</a></li>
    <li><a href="#" data-constant='ALL'     class='contactor-change-params'>All</a></li>
    <li><a href="#" data-constant='TRASH'   class='contactor-change-params'>Trash</a></li>
</ul>

<div class="contactor-inbox">
    <table id="contactor-wrapper">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name & Surname</th>
                <th>Email</th>
                <th>Message</th>
                <th>Options</th>
            </tr>
        </thead>

        <tbody>  
        </tbody>

    </table>

    <ul id="pagination-wrapper" class="contactor-pagination">
    </ul>
</div>